# Trade Intelligence Dashboard (Standalone)

## What it does
- Reads live MT5 data when MetaTrader5 is available
- Shows:
  - Net PnL
  - Win rate
  - Profit factor
  - Drawdown
  - Equity curve
  - Daily PnL
  - Symbol performance
  - Hourly edge
  - Open trades
  - Closed trades
- Supports a background image in `assets/`
- Supports Telegram daily reports

## Background image
Place your image here:

`assets/ttttt.png`

The app also checks for:
- `tttt.png`
- `.jpg`
- `.webp`

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Telegram reports
Use the sidebar fields:
- Telegram bot token
- Chat ID

Then enable daily reports or click "Send report now".

## MT5
The dashboard uses your local MT5 terminal session if MetaTrader5 is available.
