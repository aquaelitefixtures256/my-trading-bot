import base64
import io
import math
import os
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st

try:
    import MetaTrader5 as mt5
except Exception:
    mt5 = None

try:
    from streamlit_autorefresh import st_autorefresh
except Exception:
    st_autorefresh = None


APP_TITLE = "Trade Intelligence Dashboard"
ASSETS_DIR = Path(__file__).parent / "assets"
DEFAULT_LOOKBACK_DAYS = 90


# -----------------------------
# Page setup
# -----------------------------
st.set_page_config(
    page_title=APP_TITLE,
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .stApp {
        background-color: #0b0f14;
        color: #e6edf3;
    }
    .main > div {
        padding-top: 1rem;
    }
    .block-container {
        padding-top: 1.1rem;
        padding-bottom: 2rem;
    }
    .card {
        background: rgba(12, 18, 26, 0.72);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 22px;
        padding: 18px 18px 14px 18px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.28);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
    }
    .metric-label {
        font-size: 0.88rem;
        opacity: 0.82;
        margin-bottom: 0.15rem;
    }
    .metric-value {
        font-size: 1.75rem;
        font-weight: 700;
        line-height: 1.1;
    }
    .small-muted {
        font-size: 0.82rem;
        opacity: 0.72;
    }
    .section-title {
        font-size: 1.22rem;
        font-weight: 700;
        margin: 0.25rem 0 0.75rem 0;
    }
    .insight-box {
        background: rgba(95, 111, 255, 0.12);
        border: 1px solid rgba(95, 111, 255, 0.28);
        border-radius: 18px;
        padding: 14px 16px;
    }
    .warning-box {
        background: rgba(255, 188, 66, 0.10);
        border: 1px solid rgba(255, 188, 66, 0.30);
        border-radius: 18px;
        padding: 14px 16px;
    }
    .success-box {
        background: rgba(44, 199, 111, 0.10);
        border: 1px solid rgba(44, 199, 111, 0.28);
        border-radius: 18px;
        padding: 14px 16px;
    }
    .stButton > button {
        border-radius: 14px;
        border: 1px solid rgba(255,255,255,0.12);
        background: rgba(255,255,255,0.05);
        color: white;
        padding: 0.5rem 0.9rem;
    }
    .stButton > button:hover {
        border-color: rgba(120,160,255,0.55);
    }
    </style>
    """,
    unsafe_allow_html=True,
)


def set_background_from_assets():
    if not ASSETS_DIR.exists():
        return

    candidates = [
        "ttttt.png",
        "tttt.png",
        "ttttt.jpg",
        "tttt.jpg",
        "ttttt.webp",
        "tttt.webp",
    ]
    path = None
    for name in candidates:
        p = ASSETS_DIR / name
        if p.exists():
            path = p
            break

    if path is None:
        for p in sorted(ASSETS_DIR.glob("*")):
            if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
                path = p
                break

    if path is None:
        return

    try:
        mime = "image/png"
        if path.suffix.lower() in {".jpg", ".jpeg"}:
            mime = "image/jpeg"
        elif path.suffix.lower() == ".webp":
            mime = "image/webp"
        img_b64 = base64.b64encode(path.read_bytes()).decode("utf-8")
        st.markdown(
            f"""
            <style>
            .stApp {{
                background-image:
                    linear-gradient(rgba(8, 12, 18, 0.78), rgba(8, 12, 18, 0.78)),
                    url("data:{mime};base64,{img_b64}");
                background-size: cover;
                background-position: center center;
                background-attachment: fixed;
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )
    except Exception:
        return


set_background_from_assets()


# -----------------------------
# Helpers
# -----------------------------
def fmt_num(x, digits=2):
    try:
        return f"{float(x):,.{digits}f}"
    except Exception:
        return "0.00"


def safe_dt(ts) -> Optional[datetime]:
    if ts is None:
        return None
    try:
        return datetime.fromtimestamp(int(ts))
    except Exception:
        return None


def detect_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize common MT5/csv trade-history column names where possible."""
    if df is None or df.empty:
        return df

    rename_map = {}
    lower_cols = {c.lower(): c for c in df.columns}

    aliases = {
        "time": ["time", "datetime", "date", "close_time", "deal_time", "timestamp"],
        "symbol": ["symbol", "pair", "instrument"],
        "profit": ["profit", "pnl", "net", "result"],
        "commission": ["commission"],
        "swap": ["swap"],
        "volume": ["volume", "lots", "lot"],
        "type": ["type", "side", "direction"],
        "price": ["price", "close_price", "open_price"],
    }

    for std, options in aliases.items():
        for opt in options:
            if opt in lower_cols:
                rename_map[lower_cols[opt]] = std
                break

    return df.rename(columns=rename_map)


def mt5_available() -> bool:
    return mt5 is not None


def init_mt5() -> Tuple[bool, str]:
    if mt5 is None:
        return False, "MetaTrader5 package is not available."

    try:
        ok = mt5.initialize()
        if not ok:
            return False, f"MT5 initialize() failed: {mt5.last_error()}"
        return True, "MT5 connected."
    except Exception as e:
        return False, f"MT5 connection error: {e}"


def get_mt5_account_data() -> Dict:
    if mt5 is None:
        return {"ok": False, "error": "MetaTrader5 package not installed."}

    try:
        if not mt5.initialize():
            return {"ok": False, "error": f"MT5 initialize failed: {mt5.last_error()}"}

        account = mt5.account_info()
        if account is None:
            return {"ok": False, "error": "No MT5 account info returned."}

        positions = mt5.positions_get() or []
        return {"ok": True, "account": account, "positions": positions}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def fetch_mt5_history(days: int = DEFAULT_LOOKBACK_DAYS) -> pd.DataFrame:
    if mt5 is None:
        return pd.DataFrame()

    try:
        if not mt5.initialize():
            return pd.DataFrame()

        end = datetime.now()
        start = end - timedelta(days=days)
        deals = mt5.history_deals_get(start, end)
        if deals is None:
            return pd.DataFrame()

        rows = [d._asdict() for d in deals]
        df = pd.DataFrame(rows)
        if df.empty:
            return df

        df = detect_columns(df)

        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"], unit="s", errors="coerce")
        elif "time_msc" in df.columns:
            df["time"] = pd.to_datetime(df["time_msc"], unit="ms", errors="coerce")

        for col in ["profit", "commission", "swap", "volume", "price"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

        if "symbol" not in df.columns:
            df["symbol"] = "UNKNOWN"

        if "profit" not in df.columns:
            df["profit"] = 0.0
        if "commission" not in df.columns:
            df["commission"] = 0.0
        if "swap" not in df.columns:
            df["swap"] = 0.0

        df["net"] = df["profit"] + df["commission"] + df["swap"]
        df = df.sort_values("time").reset_index(drop=True)
        return df
    except Exception:
        return pd.DataFrame()


def fetch_open_positions() -> pd.DataFrame:
    if mt5 is None:
        return pd.DataFrame()
    try:
        if not mt5.initialize():
            return pd.DataFrame()

        positions = mt5.positions_get()
        if positions is None:
            return pd.DataFrame()

        rows = [p._asdict() for p in positions]
        df = pd.DataFrame(rows)
        if df.empty:
            return df

        df = detect_columns(df)

        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"], unit="s", errors="coerce")
        elif "time_msc" in df.columns:
            df["time"] = pd.to_datetime(df["time_msc"], unit="ms", errors="coerce")

        for col in ["profit", "commission", "swap", "volume", "price_open", "price_current"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

        if "profit" not in df.columns:
            df["profit"] = 0.0

        return df.sort_values(by="time" if "time" in df.columns else df.columns[0], ascending=False).reset_index(drop=True)
    except Exception:
        return pd.DataFrame()


def compute_metrics(closed: pd.DataFrame, open_positions: pd.DataFrame) -> Dict:
    metrics = {
        "closed_trades": len(closed) if closed is not None else 0,
        "open_positions": len(open_positions) if open_positions is not None else 0,
        "net_pnl": 0.0,
        "gross_profit": 0.0,
        "gross_loss": 0.0,
        "profit_factor": 0.0,
        "win_rate": 0.0,
        "max_drawdown": 0.0,
        "max_drawdown_pct": 0.0,
        "equity_curve": pd.DataFrame(),
        "daily_pnl": pd.DataFrame(),
        "symbol_perf": pd.DataFrame(),
        "hourly_edge": pd.DataFrame(),
        "recent_trades": pd.DataFrame(),
    }

    if closed is None or closed.empty:
        return metrics

    df = closed.copy()
    if "time" not in df.columns:
        return metrics

    df = df.dropna(subset=["time"]).sort_values("time").reset_index(drop=True)
    if "net" not in df.columns:
        df["net"] = 0.0

    metrics["net_pnl"] = float(df["net"].sum())
    wins = (df["net"] > 0).sum()
    losses = (df["net"] < 0).sum()
    total = wins + losses
    metrics["win_rate"] = (wins / total * 100.0) if total > 0 else 0.0

    gross_profit = float(df.loc[df["net"] > 0, "net"].sum())
    gross_loss = float(df.loc[df["net"] < 0, "net"].sum())  # negative
    metrics["gross_profit"] = gross_profit
    metrics["gross_loss"] = gross_loss
    metrics["profit_factor"] = (gross_profit / abs(gross_loss)) if gross_loss < 0 else (float("inf") if gross_profit > 0 else 0.0)

    eq = df[["time", "net"]].copy()
    eq["equity"] = eq["net"].cumsum()
    eq["peak"] = eq["equity"].cummax()
    eq["drawdown"] = eq["peak"] - eq["equity"]
    eq["drawdown_pct"] = eq["drawdown"] / eq["peak"].replace(0, pd.NA)
    eq["drawdown_pct"] = eq["drawdown_pct"].fillna(0.0)
    metrics["equity_curve"] = eq

    metrics["max_drawdown"] = float(eq["drawdown"].max()) if not eq.empty else 0.0
    metrics["max_drawdown_pct"] = float(eq["drawdown_pct"].max() * 100.0) if not eq.empty else 0.0

    df["date"] = df["time"].dt.date
    metrics["daily_pnl"] = df.groupby("date", as_index=False)["net"].sum().sort_values("date")

    if "symbol" in df.columns:
        sym = df.groupby("symbol", as_index=False)["net"].sum().sort_values("net", ascending=False)
        metrics["symbol_perf"] = sym

    df["hour"] = df["time"].dt.hour
    h = (
        df.groupby("hour", as_index=False)
        .agg(net=("net", "sum"), count=("net", "count"))
        .sort_values("hour")
    )
    metrics["hourly_edge"] = h

    recent = df.sort_values("time", ascending=False).head(20).copy()
    metrics["recent_trades"] = recent

    return metrics


def ai_insights(closed: pd.DataFrame, metrics: Dict, open_positions: pd.DataFrame) -> List[str]:
    insights = []

    net = metrics.get("net_pnl", 0.0)
    wr = metrics.get("win_rate", 0.0)
    pf = metrics.get("profit_factor", 0.0)
    dd_pct = metrics.get("max_drawdown_pct", 0.0)
    open_n = metrics.get("open_positions", 0)

    if closed is None or closed.empty:
        return ["No closed trades were found yet. The dashboard will start producing insights once MT5 history is available."]

    if net > 0:
        insights.append(f"Your closed history is positive with net PnL of {fmt_num(net)}.")
    else:
        insights.append(f"Your closed history is currently negative with net PnL of {fmt_num(net)}.")

    if wr >= 60:
        insights.append(f"Win rate is strong at {wr:.1f}%.")
    elif wr >= 50:
        insights.append(f"Win rate is decent at {wr:.1f}%, but there is room to improve trade quality.")
    else:
        insights.append(f"Win rate is below 50% at {wr:.1f}%, so entry filtering deserves attention.")

    if pf >= 1.8:
        insights.append(f"Profit factor is healthy at {pf:.2f}.")
    elif pf >= 1.2:
        insights.append(f"Profit factor is acceptable at {pf:.2f}, but costs or stop placement may still be heavy.")
    else:
        insights.append(f"Profit factor is weak at {pf:.2f}; losers are outweighing winners.")

    if dd_pct >= 15:
        insights.append(f"Drawdown is high at {dd_pct:.1f}%. Tight risk control may help.")
    elif dd_pct >= 8:
        insights.append(f"Drawdown is moderate at {dd_pct:.1f}%.")
    else:
        insights.append(f"Drawdown is relatively contained at {dd_pct:.1f}%.")

    if "symbol" in closed.columns and "net" in closed.columns:
        by_symbol = closed.groupby("symbol")["net"].sum().sort_values()
        if not by_symbol.empty:
            worst_symbol = by_symbol.index[0]
            worst_val = by_symbol.iloc[0]
            best_symbol = by_symbol.index[-1]
            best_val = by_symbol.iloc[-1]
            if worst_val < 0:
                insights.append(f"The weakest symbol in this sample is {worst_symbol} with {fmt_num(worst_val)} net.")
            if best_val > 0:
                insights.append(f"The strongest symbol in this sample is {best_symbol} with {fmt_num(best_val)} net.")

    if "hour" in closed.columns and "net" in closed.columns:
        by_hour = closed.groupby("hour")["net"].mean()
        if not by_hour.empty:
            best_hour = int(by_hour.idxmax())
            worst_hour = int(by_hour.idxmin())
            insights.append(f"Best average hour in the sample is {best_hour:02d}:00.")
            if by_hour.min() < 0:
                insights.append(f"Weakest average hour is {worst_hour:02d}:00, which may be your higher-risk window.")

    if open_n > 0:
        insights.append(f"There are currently {open_n} open positions, so exposure is active right now.")

    if len(closed) >= 10:
        recent_10 = closed.sort_values("time").tail(10)
        recent_sum = float(recent_10["net"].sum()) if "net" in recent_10.columns else 0.0
        if recent_sum < 0:
            insights.append("The last 10 closed trades are negative, so performance may be cooling off recently.")
        elif recent_sum > 0:
            insights.append("The last 10 closed trades are positive, which suggests recent momentum is better.")

    return insights[:8]


def risk_warnings(metrics: Dict, closed: pd.DataFrame, open_positions: pd.DataFrame) -> List[str]:
    warnings = []

    net = metrics.get("net_pnl", 0.0)
    dd_pct = metrics.get("max_drawdown_pct", 0.0)
    open_n = metrics.get("open_positions", 0)

    if dd_pct >= 15:
        warnings.append(f"High drawdown detected: {dd_pct:.1f}%")
    if net < 0:
        warnings.append("Net PnL is negative on the selected history window.")
    if open_n >= 8:
        warnings.append(f"Open exposure is high with {open_n} active positions.")
    if closed is not None and not closed.empty and "net" in closed.columns:
        recent = closed.sort_values("time").tail(10)
        if len(recent) >= 5 and (recent["net"] < 0).sum() >= 4:
            warnings.append("Recent trades show a cluster of losses.")
    if open_positions is not None and not open_positions.empty and "profit" in open_positions.columns:
        live_unreal = float(open_positions["profit"].sum())
        if live_unreal < 0:
            warnings.append(f"Open positions are currently negative: {fmt_num(live_unreal)}")

    return warnings


def plot_equity_curve(eq: pd.DataFrame):
    fig = go.Figure()
    if eq is not None and not eq.empty:
        fig.add_trace(go.Scatter(
            x=eq["time"],
            y=eq["equity"],
            mode="lines",
            name="Equity",
            line=dict(width=3),
        ))
    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.02)",
        font=dict(color="white"),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
        legend=dict(orientation="h"),
    )
    return fig


def plot_daily_pnl(df: pd.DataFrame):
    fig = go.Figure()
    if df is not None and not df.empty:
        fig.add_trace(go.Bar(x=df["date"], y=df["net"], name="Daily PnL"))
    fig.update_layout(
        height=330,
        margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.02)",
        font=dict(color="white"),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
        showlegend=False,
    )
    return fig


def plot_symbol_perf(df: pd.DataFrame):
    fig = go.Figure()
    if df is not None and not df.empty:
        fig.add_trace(go.Bar(
            x=df["symbol"].astype(str),
            y=df["net"],
            name="Symbol Performance"
        ))
    fig.update_layout(
        height=330,
        margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.02)",
        font=dict(color="white"),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
        showlegend=False,
    )
    return fig


def plot_hourly_edge(df: pd.DataFrame):
    fig = go.Figure()
    if df is not None and not df.empty:
        fig.add_trace(go.Bar(x=df["hour"], y=df["net"], name="Hourly Edge"))
    fig.update_layout(
        height=330,
        margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.02)",
        font=dict(color="white"),
        xaxis=dict(showgrid=False),
        yaxis=dict(showgrid=True, gridcolor="rgba(255,255,255,0.08)"),
        showlegend=False,
    )
    return fig


def send_telegram_report(bot_token: str, chat_id: str, text: str) -> Tuple[bool, str]:
    if not bot_token or not chat_id:
        return False, "Bot token or chat id missing."
    try:
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        resp = requests.post(url, data={"chat_id": chat_id, "text": text}, timeout=15)
        if resp.status_code != 200:
            return False, f"Telegram API returned {resp.status_code}: {resp.text[:180]}"
        return True, "Report sent."
    except Exception as e:
        return False, str(e)


def build_report_text(metrics: Dict, warnings: List[str], insights: List[str]) -> str:
    lines = [
        "📊 Daily Trading Report",
        f"Net PnL: {fmt_num(metrics.get('net_pnl', 0.0))}",
        f"Win Rate: {metrics.get('win_rate', 0.0):.1f}%",
        f"Profit Factor: {metrics.get('profit_factor', 0.0):.2f}",
        f"Max Drawdown: {fmt_num(metrics.get('max_drawdown', 0.0))} ({metrics.get('max_drawdown_pct', 0.0):.1f}%)",
        f"Open Positions: {metrics.get('open_positions', 0)}",
    ]
    if warnings:
        lines.append("")
        lines.append("Risk Warnings:")
        for w in warnings[:6]:
            lines.append(f"- {w}")
    if insights:
        lines.append("")
        lines.append("AI Insights:")
        for item in insights[:6]:
            lines.append(f"- {item}")
    return "\n".join(lines)


# -----------------------------
# Session defaults
# -----------------------------
if "last_daily_report_date" not in st.session_state:
    st.session_state.last_daily_report_date = None
if "last_report_status" not in st.session_state:
    st.session_state.last_report_status = ""


# -----------------------------
# Sidebar
# -----------------------------
st.sidebar.title("Control Panel")

refresh_seconds = st.sidebar.slider("Auto-refresh live trades (seconds)", 0, 300, 30, 5)
lookback_days = st.sidebar.slider("History lookback (days)", 7, 365, DEFAULT_LOOKBACK_DAYS, 1)
mt5_timeout_note = st.sidebar.caption("MT5 live mode reads your currently open positions and trade history from MetaTrader 5.")

enable_telegram = st.sidebar.toggle("Telegram daily reports", value=False)
bot_token = st.sidebar.text_input("Telegram bot token", type="password", placeholder="123456:ABC-DEF...")
chat_id = st.sidebar.text_input("Telegram chat id", placeholder="123456789")
report_time = st.sidebar.time_input("Send daily report at", value=datetime.now().replace(hour=20, minute=0, second=0, microsecond=0).time())
send_now = st.sidebar.button("Send report now")

show_raw = st.sidebar.toggle("Show raw tables", value=True)

if refresh_seconds > 0:
    if st_autorefresh is not None:
        st_autorefresh(interval=refresh_seconds * 1000, key="live_refresh")
    else:
        st.sidebar.warning("Auto-refresh helper unavailable; install streamlit-autorefresh for smoother refreshes.")


# -----------------------------
# Header
# -----------------------------
st.markdown(
    "<div class='card'>"
    f"<div class='section-title'>{APP_TITLE}</div>"
    "<div class='small-muted'>Standalone live MT5 analytics, risk intelligence, and Telegram reporting.</div>"
    "</div>",
    unsafe_allow_html=True,
)

# -----------------------------
# Data loading
# -----------------------------
with st.spinner("Loading live MT5 data..."):
    mt5_ok, mt5_msg = init_mt5() if mt5_available() else (False, "MetaTrader5 package not installed.")
    closed_trades = fetch_mt5_history(lookback_days) if mt5_ok else pd.DataFrame()
    open_positions = fetch_open_positions() if mt5_ok else pd.DataFrame()

metrics = compute_metrics(closed_trades, open_positions)
insights = ai_insights(closed_trades, metrics, open_positions)
warnings = risk_warnings(metrics, closed_trades, open_positions)

# Auto send daily Telegram report when enabled
if enable_telegram and bot_token and chat_id:
    now = datetime.now()
    target_dt = datetime.combine(now.date(), report_time)
    if now >= target_dt and st.session_state.last_daily_report_date != now.date():
        report_text = build_report_text(metrics, warnings, insights)
        ok, msg = send_telegram_report(bot_token, chat_id, report_text)
        st.session_state.last_daily_report_date = now.date()
        st.session_state.last_report_status = msg if ok else f"Failed: {msg}"

if send_now:
    report_text = build_report_text(metrics, warnings, insights)
    ok, msg = send_telegram_report(bot_token, chat_id, report_text)
    st.session_state.last_report_status = msg if ok else f"Failed: {msg}"


# -----------------------------
# Summary cards
# -----------------------------
kpi_cols = st.columns(4)
cards = [
    ("Net PnL", fmt_num(metrics["net_pnl"]), "Selected MT5 closed trades"),
    ("Win Rate", f"{metrics['win_rate']:.1f}%", f"{metrics['closed_trades']} closed trades"),
    ("Profit Factor", "∞" if math.isinf(metrics["profit_factor"]) else f"{metrics['profit_factor']:.2f}", "Gross profit / gross loss"),
    ("Max Drawdown", f"{fmt_num(metrics['max_drawdown'])} ({metrics['max_drawdown_pct']:.1f}%)", "Peak-to-trough on equity curve"),
]
for col, (label, value, sub) in zip(kpi_cols, cards):
    with col:
        st.markdown(
            f"<div class='card'>"
            f"<div class='metric-label'>{label}</div>"
            f"<div class='metric-value'>{value}</div>"
            f"<div class='small-muted'>{sub}</div>"
            f"</div>",
            unsafe_allow_html=True,
        )

st.write("")

# -----------------------------
# Warnings and insights
# -----------------------------
left, right = st.columns([1, 1])

with left:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Risk Warnings</div>", unsafe_allow_html=True)
    if warnings:
        st.markdown(
            "<div class='warning-box'>" + "<br>".join([f"• {w}" for w in warnings]) + "</div>",
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            "<div class='success-box'>No major risk warnings from the selected history window.</div>",
            unsafe_allow_html=True,
        )
    st.markdown("</div>", unsafe_allow_html=True)

with right:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>AI Insights</div>", unsafe_allow_html=True)
    st.markdown(
        "<div class='insight-box'>" + "<br>".join([f"• {x}" for x in insights]) + "</div>",
        unsafe_allow_html=True,
    )
    if st.session_state.last_report_status:
        st.caption(f"Telegram: {st.session_state.last_report_status}")
    st.markdown("</div>", unsafe_allow_html=True)

st.write("")

# -----------------------------
# Charts
# -----------------------------
chart_cols = st.columns(2)
with chart_cols[0]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Equity Curve</div>", unsafe_allow_html=True)
    st.plotly_chart(plot_equity_curve(metrics["equity_curve"]), use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

with chart_cols[1]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Daily PnL</div>", unsafe_allow_html=True)
    st.plotly_chart(plot_daily_pnl(metrics["daily_pnl"]), use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

chart_cols2 = st.columns(2)
with chart_cols2[0]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Symbol Performance</div>", unsafe_allow_html=True)
    st.plotly_chart(plot_symbol_perf(metrics["symbol_perf"]), use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

with chart_cols2[1]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Hourly Edge</div>", unsafe_allow_html=True)
    st.plotly_chart(plot_hourly_edge(metrics["hourly_edge"]), use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

st.write("")

# -----------------------------
# Trade tables
# -----------------------------
tables_cols = st.columns(2)

with tables_cols[0]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Open Trades</div>", unsafe_allow_html=True)
    if open_positions is not None and not open_positions.empty:
        show_cols = [c for c in ["time", "symbol", "type", "volume", "price_open", "price_current", "profit", "swap", "commission"] if c in open_positions.columns]
        df_show = open_positions[show_cols].copy() if show_cols else open_positions.copy()
        st.dataframe(df_show, use_container_width=True, height=280)
    else:
        st.info("No open positions found.")
    st.markdown("</div>", unsafe_allow_html=True)

with tables_cols[1]:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='section-title'>Closed Trades</div>", unsafe_allow_html=True)
    if closed_trades is not None and not closed_trades.empty:
        show_cols = [c for c in ["time", "symbol", "type", "volume", "price", "net", "profit", "swap", "commission"] if c in closed_trades.columns]
        df_show = closed_trades.sort_values("time", ascending=False)[show_cols].head(50).copy() if show_cols else closed_trades.head(50).copy()
        st.dataframe(df_show, use_container_width=True, height=280)
    else:
        st.info("No closed trades found in the selected history window.")
    st.markdown("</div>", unsafe_allow_html=True)

if show_raw:
    st.write("")
    with st.expander("Raw MT5 data snapshot", expanded=False):
        st.write("Live connection:", mt5_msg)
        st.write("History rows:", len(closed_trades))
        st.write("Open rows:", len(open_positions))
        if closed_trades is not None and not closed_trades.empty:
            st.dataframe(closed_trades.head(20), use_container_width=True)
        if open_positions is not None and not open_positions.empty:
            st.dataframe(open_positions.head(20), use_container_width=True)

st.caption("This dashboard is standalone and does not modify your trading bot.")
