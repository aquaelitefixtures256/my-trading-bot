import base64
import io
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

try:
    import MetaTrader5 as mt5
except Exception:
    mt5 = None

APP_TITLE = "Trade Intelligence Dashboard"
DEFAULT_BG_CANDIDATES = [
    "assets/bot_background.png",
    "assets/bot_background.jpg",
    "assets/bot_background.jpeg",
    "assets/bot_background.webp",
]


def set_page_style():
    st.set_page_config(
        page_title=APP_TITLE,
        page_icon="📈",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    bg_css = ""
    bg_path = next((p for p in DEFAULT_BG_CANDIDATES if Path(p).exists()), None)
    if bg_path:
        mime = "image/png"
        if bg_path.lower().endswith(".jpg") or bg_path.lower().endswith(".jpeg"):
            mime = "image/jpeg"
        elif bg_path.lower().endswith(".webp"):
            mime = "image/webp"
        b64 = base64.b64encode(Path(bg_path).read_bytes()).decode()
        bg_css = f"""
        .stApp {{
            background:
                linear-gradient(rgba(7, 11, 20, 0.82), rgba(7, 11, 20, 0.90)),
                url("data:{mime};base64,{b64}");
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }}
        """
    else:
        bg_css = """
        .stApp {
            background:
                radial-gradient(circle at top left, rgba(74, 111, 165, 0.18), transparent 32%),
                radial-gradient(circle at top right, rgba(47, 132, 255, 0.12), transparent 22%),
                linear-gradient(180deg, #08111f 0%, #050812 100%);
        }
        """

    st.markdown(
        f"""
        <style>
        {bg_css}

        .block-container {{
            padding-top: 1.25rem;
            padding-bottom: 2rem;
        }}

        .glass {{
            background: rgba(13, 18, 30, 0.72);
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 22px;
            padding: 18px 18px 12px 18px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.32);
            backdrop-filter: blur(16px);
        }}

        .hero {{
            padding: 26px 24px;
            border-radius: 28px;
            background: linear-gradient(135deg, rgba(27, 39, 66, 0.88), rgba(9, 14, 25, 0.76));
            border: 1px solid rgba(255,255,255,0.08);
            box-shadow: 0 18px 60px rgba(0,0,0,0.35);
        }}

        .hero h1 {{
            margin: 0;
            font-size: 2.2rem;
            line-height: 1.05;
        }}

        .hero p {{
            margin: 0.35rem 0 0 0;
            color: rgba(230, 238, 255, 0.78);
            font-size: 0.98rem;
        }}

        div[data-testid="metric-container"] {{
            background: rgba(13, 18, 30, 0.75);
            border: 1px solid rgba(255,255,255,0.08);
            padding: 14px 16px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.22);
        }}

        div[data-testid="metric-container"] label {{
            color: rgba(225, 232, 255, 0.74) !important;
        }}

        .small-note {{
            color: rgba(228, 235, 255, 0.66);
            font-size: 0.86rem;
        }}

        .stTabs [data-baseweb="tab-list"] button {{
            font-weight: 600;
        }}

        .stDownloadButton button, .stButton button {{
            border-radius: 14px;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def money(x):
    try:
        return f"{float(x):,.2f}"
    except Exception:
        return "0.00"


def pct(x):
    try:
        return f"{float(x):.1f}%"
    except Exception:
        return "0.0%"


def infer_col(df, options):
    cols = {c.lower().strip(): c for c in df.columns}
    for opt in options:
        if opt.lower() in cols:
            return cols[opt.lower()]
    # fuzzy contains
    for opt in options:
        for low, orig in cols.items():
            if opt.lower() in low:
                return orig
    return None


def normalize_history(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if df.empty:
        return df

    time_col = infer_col(df, ["time", "date", "datetime", "open_time", "close_time", "timestamp"])
    if time_col is None:
        # synthetic if no time column
        df["time"] = pd.RangeIndex(len(df))
        time_col = "time"

    symbol_col = infer_col(df, ["symbol", "pair", "instrument"])
    type_col = infer_col(df, ["type", "side", "direction", "trade_type"])
    profit_col = infer_col(df, ["profit", "pnl", "net_profit", "result", "net"])
    volume_col = infer_col(df, ["volume", "lot", "lots", "size"])
    open_col = infer_col(df, ["open_price", "entry_price", "price_open", "entry"])
    close_col = infer_col(df, ["close_price", "price_close", "exit_price", "exit"])
    status_col = infer_col(df, ["status", "state", "closed"])
    id_col = infer_col(df, ["ticket", "id", "deal", "order"])

    rename = {}
    if time_col: rename[time_col] = "time"
    if symbol_col: rename[symbol_col] = "symbol"
    if type_col: rename[type_col] = "side"
    if profit_col: rename[profit_col] = "profit"
    if volume_col: rename[volume_col] = "volume"
    if open_col: rename[open_col] = "open_price"
    if close_col: rename[close_col] = "close_price"
    if status_col: rename[status_col] = "status"
    if id_col: rename[id_col] = "id"

    df = df.rename(columns=rename)

    if "time" in df.columns:
        try:
            df["time"] = pd.to_datetime(df["time"], errors="coerce", utc=False)
        except Exception:
            pass

    if "profit" not in df.columns:
        df["profit"] = 0.0
    df["profit"] = pd.to_numeric(df["profit"], errors="coerce").fillna(0.0)

    if "symbol" not in df.columns:
        df["symbol"] = "UNKNOWN"

    if "side" not in df.columns:
        df["side"] = "UNKNOWN"
    else:
        df["side"] = df["side"].astype(str).str.upper()

    if "status" not in df.columns:
        df["status"] = "closed"
    else:
        df["status"] = df["status"].astype(str).str.lower()

    if "volume" not in df.columns:
        df["volume"] = 0.0
    else:
        df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)

    if "open_price" not in df.columns:
        df["open_price"] = pd.NA
    if "close_price" not in df.columns:
        df["close_price"] = pd.NA
    if "id" not in df.columns:
        df["id"] = range(1, len(df) + 1)

    return df


def load_csv(uploaded_file):
    if uploaded_file is None:
        return None
    try:
        data = pd.read_csv(uploaded_file)
        return normalize_history(data)
    except Exception as e:
        st.error(f"CSV load failed: {e}")
        return None


def mt5_connected():
    if mt5 is None:
        return False
    try:
        return mt5.initialize()
    except Exception:
        return False


def load_mt5_data():
    if mt5 is None:
        raise RuntimeError("MetaTrader5 package is not installed.")
    if not mt5.initialize():
        raise RuntimeError("Could not initialize MetaTrader 5.")

    account = mt5.account_info()
    positions = mt5.positions_get()
    history = None
    try:
        history = mt5.history_deals_get(datetime(1970, 1, 1), datetime.now())
    except Exception:
        history = None

    open_df = pd.DataFrame(list(positions), columns=positions[0]._asdict().keys()) if positions else pd.DataFrame()
    closed_df = pd.DataFrame([d._asdict() for d in history]) if history else pd.DataFrame()

    if not open_df.empty:
        open_df = open_df.rename(columns={
            "ticket": "id",
            "time": "time",
            "symbol": "symbol",
            "type": "side",
            "volume": "volume",
            "price_open": "open_price",
            "price_current": "current_price",
            "profit": "profit",
        })
        if "time" in open_df.columns:
            open_df["time"] = pd.to_datetime(open_df["time"], unit="s", errors="coerce")
        if "side" in open_df.columns:
            open_df["side"] = open_df["side"].astype(str)
        open_df["status"] = "open"

    if not closed_df.empty:
        closed_df = closed_df.rename(columns={
            "ticket": "id",
            "time": "time",
            "symbol": "symbol",
            "type": "side",
            "volume": "volume",
            "price": "price",
            "profit": "profit",
        })
        if "time" in closed_df.columns:
            closed_df["time"] = pd.to_datetime(closed_df["time"], unit="s", errors="coerce")
        if "profit" not in closed_df.columns:
            closed_df["profit"] = 0.0
        closed_df["status"] = "closed"

    summary = {}
    if account is not None:
        summary = account._asdict()

    return summary, open_df, closed_df


def equity_curve(df: pd.DataFrame):
    if df.empty or "time" not in df.columns:
        return pd.DataFrame(columns=["time", "equity"])
    x = df.sort_values("time").copy()
    x["equity"] = x["profit"].cumsum()
    x["drawdown"] = x["equity"] - x["equity"].cummax()
    return x[["time", "equity", "drawdown"]]


def max_drawdown(curve: pd.DataFrame) -> float:
    if curve.empty:
        return 0.0
    return float(curve["drawdown"].min())


def profit_factor(df: pd.DataFrame) -> float:
    if df.empty:
        return 0.0
    gains = df.loc[df["profit"] > 0, "profit"].sum()
    losses = -df.loc[df["profit"] < 0, "profit"].sum()
    if losses == 0:
        return float("inf") if gains > 0 else 0.0
    return float(gains / losses)


def win_rate(df: pd.DataFrame) -> float:
    if df.empty:
        return 0.0
    total = len(df)
    wins = (df["profit"] > 0).sum()
    return float(wins / total * 100.0)


def daily_pnl(df: pd.DataFrame):
    if df.empty or "time" not in df.columns:
        return pd.DataFrame(columns=["date", "pnl"])
    x = df.copy()
    x["date"] = pd.to_datetime(x["time"], errors="coerce").dt.date
    return x.groupby("date", as_index=False)["profit"].sum().rename(columns={"profit": "pnl"})


def hourly_edge(df: pd.DataFrame):
    if df.empty or "time" not in df.columns:
        return pd.DataFrame(columns=["hour", "pnl"])
    x = df.copy()
    x["hour"] = pd.to_datetime(x["time"], errors="coerce").dt.hour
    return x.groupby("hour", as_index=False)["profit"].sum().rename(columns={"profit": "pnl"})


def symbol_perf(df: pd.DataFrame):
    if df.empty:
        return pd.DataFrame(columns=["symbol", "pnl", "trades", "win_rate"])
    x = df.copy()
    g = x.groupby("symbol").agg(
        pnl=("profit", "sum"),
        trades=("profit", "size"),
        wins=("profit", lambda s: int((s > 0).sum())),
    ).reset_index()
    g["win_rate"] = g["wins"] / g["trades"] * 100.0
    return g.sort_values("pnl", ascending=False)


def trade_type_perf(df: pd.DataFrame):
    if df.empty:
        return pd.DataFrame(columns=["side", "pnl", "trades"])
    x = df.copy()
    return x.groupby("side", as_index=False).agg(pnl=("profit", "sum"), trades=("profit", "size")).sort_values("pnl", ascending=False)


def recent_trades(df: pd.DataFrame, n=12):
    if df.empty:
        return df
    cols = [c for c in ["time", "symbol", "side", "volume", "open_price", "close_price", "profit", "status", "id"] if c in df.columns]
    return df.sort_values("time", ascending=False).head(n)[cols]


def render_kpis(df: pd.DataFrame):
    curve = equity_curve(df)
    total_pnl = float(df["profit"].sum()) if not df.empty else 0.0
    wr = win_rate(df)
    pf = profit_factor(df)
    mdd = max_drawdown(curve)
    trades = len(df)
    wins = int((df["profit"] > 0).sum()) if not df.empty else 0
    losses = int((df["profit"] < 0).sum()) if not df.empty else 0

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Net PnL", money(total_pnl))
    c2.metric("Win Rate", pct(wr))
    c3.metric("Profit Factor", "∞" if math.isinf(pf) else f"{pf:.2f}")
    c4.metric("Max Drawdown", money(mdd))

    c5, c6, c7, c8 = st.columns(4)
    c5.metric("Trades", f"{trades}")
    c6.metric("Wins", f"{wins}")
    c7.metric("Losses", f"{losses}")
    c8.metric("Avg / Trade", money(total_pnl / trades if trades else 0.0))


def main():
    set_page_style()

    st.markdown(
        """
        <div class="hero">
            <h1>📈 Trade Intelligence Dashboard</h1>
            <p>Beautiful standalone analytics for your MT5 history, CSV exports, open trades, closed trades, edge patterns, and performance tracking.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.sidebar.markdown("## Data source")
    source = st.sidebar.radio("Choose data source", ["CSV upload", "MT5 live"], index=0)

    st.sidebar.markdown("## Filters")
    min_time = None
    max_time = None

    df = pd.DataFrame()
    open_df = pd.DataFrame()
    closed_df = pd.DataFrame()
    mt5_summary = {}

    if source == "CSV upload":
        uploaded = st.sidebar.file_uploader("Upload trade history CSV", type=["csv"])
        if uploaded is not None:
            df = load_csv(uploaded) or pd.DataFrame()
        else:
            st.info("Upload a CSV trade history file to begin.")
    else:
        st.sidebar.caption("Requires MetaTrader5 installed and the platform open on the same machine.")
        if st.sidebar.button("Connect to MT5"):
            try:
                mt5_summary, open_df, closed_df = load_mt5_data()
                df = closed_df.copy()
                st.sidebar.success("MT5 connected.")
            except Exception as e:
                st.sidebar.error(str(e))
        else:
            if mt5_connected():
                try:
                    mt5_summary, open_df, closed_df = load_mt5_data()
                    df = closed_df.copy()
                except Exception as e:
                    st.sidebar.error(str(e))

    if not df.empty and "time" in df.columns:
        try:
            min_time = pd.to_datetime(df["time"], errors="coerce").min()
            max_time = pd.to_datetime(df["time"], errors="coerce").max()
        except Exception:
            pass

    if not df.empty:
        if "time" in df.columns:
            df = df.sort_values("time")
        if min_time is not None and max_time is not None and pd.notna(min_time) and pd.notna(max_time):
            start, end = st.sidebar.date_input("Date range", value=(min_time.date(), max_time.date()))
            if start and end:
                t = pd.to_datetime(df["time"], errors="coerce").dt.date
                df = df[(t >= start) & (t <= end)]

        symbols = sorted([s for s in df["symbol"].dropna().astype(str).unique().tolist()])
        selected_symbols = st.sidebar.multiselect("Symbols", symbols, default=symbols)
        if selected_symbols:
            df = df[df["symbol"].astype(str).isin(selected_symbols)]

        statuses = sorted([s for s in df["status"].dropna().astype(str).unique().tolist()])
        selected_status = st.sidebar.multiselect("Status", statuses, default=statuses)
        if selected_status:
            df = df[df["status"].astype(str).isin(selected_status)]

    tab_overview, tab_trades, tab_open, tab_closed, tab_export = st.tabs(
        ["Overview", "Trade breakdown", "Open trades", "Closed trades", "Export"]
    )

    with tab_overview:
        if df.empty:
            st.markdown('<div class="glass"><p class="small-note">No trade data loaded yet.</p></div>', unsafe_allow_html=True)
        else:
            render_kpis(df)
            st.write("")
            c1, c2 = st.columns((1.2, 1))
            with c1:
                ec = equity_curve(df)
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=ec["time"], y=ec["equity"], mode="lines", name="Equity"))
                fig.add_trace(go.Scatter(x=ec["time"], y=ec["drawdown"], mode="lines", name="Drawdown"))
                fig.update_layout(
                    title="Equity Curve & Drawdown",
                    template="plotly_dark",
                    height=420,
                    margin=dict(l=10, r=10, t=50, b=10),
                )
                st.plotly_chart(fig, use_container_width=True)

            with c2:
                dp = daily_pnl(df)
                if not dp.empty:
                    fig2 = px.bar(dp, x="date", y="pnl", title="Daily PnL")
                    fig2.update_layout(template="plotly_dark", height=420, margin=dict(l=10, r=10, t=50, b=10))
                    st.plotly_chart(fig2, use_container_width=True)

            c3, c4 = st.columns(2)
            with c3:
                sp = symbol_perf(df)
                if not sp.empty:
                    fig3 = px.bar(sp.head(12), x="symbol", y="pnl", title="Symbol Performance")
                    fig3.update_layout(template="plotly_dark", height=380, margin=dict(l=10, r=10, t=50, b=10))
                    st.plotly_chart(fig3, use_container_width=True)
            with c4:
                hp = hourly_edge(df)
                if not hp.empty:
                    fig4 = px.bar(hp, x="hour", y="pnl", title="Hourly Edge")
                    fig4.update_layout(template="plotly_dark", height=380, margin=dict(l=10, r=10, t=50, b=10))
                    st.plotly_chart(fig4, use_container_width=True)

            st.markdown("### Performance summary")
            left, right = st.columns(2)
            with left:
                st.markdown('<div class="glass">', unsafe_allow_html=True)
                st.metric("Profit Factor", "∞" if math.isinf(profit_factor(df)) else f"{profit_factor(df):.2f}")
                st.metric("Max Drawdown", money(max_drawdown(ec)))
                st.metric("Win Rate", pct(win_rate(df)))
                st.markdown("</div>", unsafe_allow_html=True)
            with right:
                st.markdown('<div class="glass">', unsafe_allow_html=True)
                st.metric("Best Symbol", sp.iloc[0]["symbol"] if not sp.empty else "N/A")
                st.metric("Best Hour", int(hp.sort_values("pnl", ascending=False).iloc[0]["hour"]) if not hp.empty else "N/A")
                st.metric("Closed Trades", int((df["status"].astype(str).str.lower() == "closed").sum()))
                st.markdown("</div>", unsafe_allow_html=True)

    with tab_trades:
        if df.empty:
            st.info("Load data to view trade breakdown.")
        else:
            st.dataframe(
                trade_type_perf(df),
                use_container_width=True,
                hide_index=True,
            )
            st.dataframe(
                symbol_perf(df),
                use_container_width=True,
                hide_index=True,
            )
            st.dataframe(
                recent_trades(df, n=20),
                use_container_width=True,
                hide_index=True,
            )

    with tab_open:
        if source == "MT5 live" and not open_df.empty:
            st.subheader("Open positions from MT5")
            st.dataframe(open_df, use_container_width=True, hide_index=True)
        elif not df.empty and "status" in df.columns:
            open_like = df[df["status"].astype(str).str.lower().str.contains("open", na=False)]
            if open_like.empty:
                st.info("No open trades found in this dataset.")
            else:
                st.dataframe(open_like, use_container_width=True, hide_index=True)
        else:
            st.info("Open trades will appear here when available.")

    with tab_closed:
        if source == "MT5 live" and not closed_df.empty:
            st.subheader("Closed trades from MT5")
            st.dataframe(closed_df, use_container_width=True, hide_index=True)
        elif not df.empty:
            closed_like = df[df["status"].astype(str).str.lower().str.contains("closed", na=False)]
            if closed_like.empty:
                st.info("No closed trades found in this dataset.")
            else:
                st.dataframe(closed_like, use_container_width=True, hide_index=True)
        else:
            st.info("Closed trades will appear here when available.")

    with tab_export:
        if df.empty:
            st.info("Load data first.")
        else:
            csv_bytes = df.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download filtered CSV",
                data=csv_bytes,
                file_name="filtered_trades.csv",
                mime="text/csv",
            )
            st.caption(
                "Tip: place your bot image as assets/bot_background.png (or .jpg/.webp) to make the dashboard use it as the background."
            )


if __name__ == "__main__":
    main()
