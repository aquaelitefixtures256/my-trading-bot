# Trade Intelligence Dashboard

A standalone Streamlit dashboard for analyzing MT5 trades or CSV exports.

## Features
- Net PnL
- Win rate
- Profit factor
- Max drawdown
- Equity curve
- Daily PnL
- Symbol performance
- Hourly edge
- Recent trades
- Open trades
- Closed trades
- Beautiful dark glass UI

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Data sources

### 1) CSV upload
Upload a trade history CSV with columns such as:
- time / date / datetime
- symbol
- side / type / direction
- profit / pnl
- volume
- status
- open_price
- close_price

The app tries to auto-detect common column names.

### 2) MT5 live
Run on the same machine where MetaTrader 5 is installed and logged in.
The dashboard will try to read:
- account info
- open positions
- closed deals

## Background image
To use your bot image as the background, place it here:

```text
assets/bot_background.png
```

You can also use:
- `assets/bot_background.jpg`
- `assets/bot_background.webp`

The dashboard will automatically use the first one it finds.

## Notes
- This app does not modify your trading bot.
- If MetaTrader5 is not installed, CSV upload still works.
